

export default function TestPage() {
	
	return(
		<div className="w-[400px] h-[400px] bg-green-600 lg:bg-blue-600 relative">
			
		</div>
	)
}
